from django.contrib import admin

# Register your models here.


from .models import DriverProfile
admin.site.register(DriverProfile)

from .models import PatientProfile
admin.site.register(PatientProfile)

from .models import Hir
admin.site.register(Hir)

from .models import CustomUser
admin.site.register(CustomUser)