from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('profil/', views.profil, name="profil" ),
    path('rendeles/', views.rendeles, name="rendeles"),
    
    path('logout/', views.logoutEmail, name="logout"),
    
    path('registerlogin/', views.reglogin, name='registerlogin'),

]