from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login, logout
from django.contrib import messages
from .forms import EmailAuthenticationForm, CustomUserCreationForm
from django.contrib.auth.decorators import login_required


def reglogin(request):
    # Get which page we are showing
    page = request.GET.get('page', 'register')

    if request.user.is_authenticated:
        return redirect('home')

    # Determine which form to use
    if page == 'loginxd':
        form = EmailAuthenticationForm()
        page = 'loginxd'
    else:
        form = CustomUserCreationForm()

    # Handle POST requests
    if request.method == "POST":
        if request.POST.get('page') == 'loginxd':
            # Login form submission
            form = EmailAuthenticationForm(request.POST)
            page = 'loginxd'
            if form.is_valid():
                email = form.cleaned_data['email']
                password = form.cleaned_data['password']
                user = authenticate(request, username=email, password=password)
                if user:
                    auth_login(request, user)
                    messages.success(request, "You are now logged in!")
                    return redirect("home")
                else:
                    messages.error(request, "Invalid email or password.")
        else:
            # Registration form submission
            form = CustomUserCreationForm(request.POST)
            page = 'register'
            if form.is_valid():
                user = form.save(commit=False)
                user.email = user.email.lower()
                user.save()
                auth_login(request, user, backend='base.auth_backends.EmailBackend')
                messages.success(request, "Registration successful! You are now logged in.")
                return redirect('home')
            else:
                messages.error(request, "Please correct the errors below.")

    return render(request, 'registerlogin.html', {'form': form, 'page': page})


def logoutEmail(request):
    logout(request)
    return redirect('home')


def home(request):
    return render(request, 'home.html')


@login_required(login_url='/registerlogin')
def profil(request):
    return render(request, 'profil.html')


@login_required(login_url='/registerlogin')
def rendeles(request):
    return render(request, 'rendeles.html')