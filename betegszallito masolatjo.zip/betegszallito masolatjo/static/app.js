document.addEventListener("DOMContentLoaded", () => {
  const sidebar = document.getElementById("sidebar");
  const menuIcon = document.getElementById("menuIcon");
  const closeSidebarBtn = document.getElementById("closeSidebarBtn");
  const content = document.getElementById("content");

  function toggleSidebar() {
    sidebar.style.width = (sidebar.style.width === "250px") ? "0" : "250px";
  }
  menuIcon.addEventListener("click", toggleSidebar);
  closeSidebarBtn.addEventListener("click", toggleSidebar);

  
});