from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model

UserModel = get_user_model()

class EmailBackend(ModelBackend):
    """
    Custom authentication backend that allows users to log in with their email.
    Case-insensitive and compatible with Django's authentication system.
    """

    def authenticate(self, request, username=None, password=None, **kwargs):
        # Accept either `username` or `email` field
        email = (username or kwargs.get('email', '')).strip().lower()
        try:
            user = UserModel.objects.get(email__iexact=email)
        except UserModel.DoesNotExist:
            return None

        if user.check_password(password) and self.user_can_authenticate(user):
            return user
        return None